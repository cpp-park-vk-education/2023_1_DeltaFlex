#include <gtest/gtest.h>

// #include "DFESceneExporter.hpp"

TEST(DFESceneExporterTest, test_CollectData)
{
}

TEST(DFESceneExporterTest, test_nothingToCollect)
{
}

TEST(DFESceneExporterTest, test_ConvertComponent)
{
}

TEST(DFESceneExporterTest, test_nothingToConvert)
{
}

TEST(DFESceneExporterTest, test_AssembleComponents)
{
}

TEST(DFESceneExporterTest, test_nothingToAssemble)
{
}
