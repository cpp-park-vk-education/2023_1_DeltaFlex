#include "DFEAssetViewer.hpp"
#include <QStyle>

DFEAssetViewer::DFEAssetViewer(QWidget *parent)
    : QListView(parent)
{
    QFileSystemModel *model = new QFileSystemModel(this);

    setFrameShape(QFrame::NoFrame);
    setViewMode(QListView::IconMode);

    model->setFilter(QDir::AllEntries | QDir::NoDotAndDotDot);
    model->setRootPath("");
    model->setFilter(QDir::NoDotAndDotDot | QDir::Files | QDir::Dirs);
    setModel(model);

    setStyleSheet("QListView { font: 12px }");

    setFlow(QListView::LeftToRight);
    setMovement(QListView::Static);
    setGridSize(QSize(100, 100));
    setResizeMode(QListView::Adjust);

    setUniformItemSizes(true);
    setWrapping(true);
    setWordWrap(true);
    setDragEnabled(true);
    setTextElideMode(Qt::ElideMiddle);
}

void DFEAssetViewer::UpdateView(const QString &dir)
{
    // if (QFileInfo(dir).isDir())
    //     setRootIndex(model()->index(dir));
}

QString DFEAssetViewer::GetDirByIndex(const QModelIndex &index)
{
    if (!this->model())
        return {};

    QFileSystemModel *model = qobject_cast<QFileSystemModel *>(this->model());
    return model->filePath(index);
}
